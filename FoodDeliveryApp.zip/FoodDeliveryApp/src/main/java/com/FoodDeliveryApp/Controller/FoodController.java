package com.FoodDeliveryApp.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.FoodDeliveryApp.Model.Item;
import com.FoodDeliveryApp.Model.ItemBooked;
import com.FoodDeliveryApp.Service.FoodBookingService;

@Controller
public class FoodController {

	@Autowired
	FoodBookingService foodservice;

	@RequestMapping("/")
	public String home()
	{
		return "Home";
	}
	
	@RequestMapping("/Order")
	public ModelAndView home(Model model) {
		//foodservice.addItem();
		List<Item> ItemList = foodservice.getfoodList();
		return new ModelAndView("foodItems", "ItemList", ItemList);
	}
	
	@RequestMapping("/newpage")
	public ModelAndView bookingList() {
		//foodservice.addItem();
		List<ItemBooked> ItemList = foodservice.getfoodBookedList();
		return new ModelAndView("bookingList", "ItemList", ItemList);
	}
	
	@RequestMapping("showItem/{id}")
	public ModelAndView viewItem(@PathVariable("id")int id)
	{
		Item item=foodservice.getItem(id);
		System.out.println(item.getImage());
		return new ModelAndView("viewItem","item",item);
	}
	
	@RequestMapping(value = "showItem/bookOrder", method = RequestMethod.POST)
	public ModelAndView bookOrder(HttpServletRequest request)
	{
		int id=Integer.parseInt(request.getParameter("itemId"));
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		foodservice.bookOrder(id,quantity);
		return new ModelAndView("redirect:/newpage");
	}
	
	@RequestMapping("cancelorder/{id}")
	public ModelAndView cancelOrder(@PathVariable("id")int id)
	{
		foodservice.cancelOrder(id);
		return new ModelAndView("redirect:/newpage");
	}

}

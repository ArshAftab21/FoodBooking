package com.FoodDeliveryApp.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.FoodDeliveryApp.Model.Item;
import com.FoodDeliveryApp.Service.FoodBookingService;

@RestController
public class FoodRestController 
{

	@Autowired
	FoodBookingService foodservice;
	
	@RequestMapping(value = "showItem/calculateCost", produces = "application/json", method = RequestMethod.POST)
	public String calculateCost(HttpServletRequest request)
	{	
		String quan=request.getParameter("quantity").trim();
		int quantity=Integer.parseInt(quan);
		String name=request.getParameter("name");
		Item item=foodservice.findItem(name);
		int price=quantity*item.getPrice();
		System.out.println(Integer.toString(price));
		return Integer.toString(price);
	}
	
	
}

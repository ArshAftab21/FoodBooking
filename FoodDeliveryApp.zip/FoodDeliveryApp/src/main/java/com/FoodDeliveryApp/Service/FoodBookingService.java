package com.FoodDeliveryApp.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.FoodDeliveryApp.Model.Item;
import com.FoodDeliveryApp.Model.ItemBooked;
import com.FoodDeliveryApp.Repository.ItemBookedRepository;
import com.FoodDeliveryApp.Repository.ItemRepository;

@Service("foodservice")
public class FoodBookingService {

	@Autowired
	ItemRepository itemRepository;

	@Autowired
	ItemBookedRepository itemBookedRepository;

	@Transactional
	public List<Item> getfoodList() {
		List<Item> list = (List<Item>) itemRepository.findAll();
		return list;
	}

	@Transactional
	public void addItem() {
		Item item = new Item("Biryani", "A world-renowned Indian dish, Long-grained rice (like basmati) flavored with exotic spices, such as saffron, is layered with lamb, chicken, fish, or vegetables, and a thick gravy.", 250, 30,"biryani.jpg");
		itemRepository.save(item);
		Item item1 = new Item("Butter Paneer", "Paneer Butter Masala is a rich and delicious North Indian recipe made with aromatic spices, cream and butter.to make the paneer cubes soft and tender", 200, 20,"butterpaneer.jpg");
		itemRepository.save(item1);
		Item item2 = new Item("Pizza", "Pizza is a dish of Italian origin, consisting of a usually round, base of wheat-based dough topped with tomatoes, cheese, and various other ingredients baked at a high temperature,", 500, 15,"pizza.jpg");
		itemRepository.save(item2);
		Item item3 = new Item("Burger", "A burger is a sandwich consisting of one or more cooked patties of ground meat, usually beef, placed inside a sliced bread roll or bun. The patty may be pan fried, grilled, or flame broiled.", 100, 30,"burger.jpg");
		itemRepository.save(item3);
		Item item4 = new Item("Noodles", "A noodle is a piece of pasta, especially a long, skinny one. You can eat noodles with butter and cheese or sauce, or slurp them from a bowl of soup. ", 300, 30,"noodles.jpg");
		itemRepository.save(item4);
		Item item5 = new Item("Paratha", "A paratha is a flatbread that originated in the Indian subcontinent where wheat is the traditional staple. Paratha  means layers of cooked dough.", 50, 100,"paratha.jpg");
		itemRepository.save(item5);
		Item item6 = new Item("Egg Roll", " An egg roll is a cylindrical, savory roll with shredded cabbage, chopped pork, and other fillings inside a thickly-wrapped wheat flour skin fried in hot oil.", 150, 40,"eggroll.jpg");
		itemRepository.save(item6);
		Item item7 = new Item("Maccroni", "Macaroni is dry pasta shaped like narrow tubes. Made with durum wheat, macaroni is commonly cut in short lengths; curved macaroni may be referred to as elbow macaroni.", 200, 20,"macroni.jpg");
		itemRepository.save(item7);
		Item item8 = new Item("Dum Aloo", "Dum Aloo is a potato based dish, it is a part of the traditional Kashmiri Pandit cuisine, from the Kashmir Valley", 70, 20,"dumaloo.jpg");
		itemRepository.save(item8);
		Item item9 = new Item("Butter chicken", "Butter chicken or murgh makhani (pronounced [mʊrg məkʰniː]) is a dish, originating in India, of chicken in a mildly spiced tomato sauce.", 180, 30,"butterchicken.jpg");
		itemRepository.save(item9);
		

	}

	@Transactional
	public Item getItem(int id) {
		Item item = (Item) itemRepository.findOne(id);
		return item;
	}

	@Transactional
	public Item findItem(String name) {
		Item item = itemRepository.findbyName(name);
		return item;
	}

	@Transactional
	public void bookOrder(int id, int quantity) {
		Item item = (Item) itemRepository.findOne(id);
		int remainingQuantity = item.getAvailable() - quantity;
		item.setAvailable(remainingQuantity);
		itemRepository.save(item);
		ItemBooked ib = new ItemBooked();
		ib.setItem(item);
		int cost = item.getPrice() * quantity;
		ib.setCost(cost);
		itemBookedRepository.save(ib);

	}

	@Transactional
	public List<ItemBooked> getfoodBookedList() {
		List<ItemBooked> list=(List<ItemBooked>)itemBookedRepository.findAll();
		return list;
	}

	@Transactional
	public void cancelOrder(int id) {
		ItemBooked itemBooked=(ItemBooked)itemBookedRepository.findOne(id);
		Item item=itemBooked.getItem();
		int cost=itemBooked.getCost();
		int priceofOne=item.getPrice();
		int quantityBooked=cost/priceofOne;
		int itemId=item.getId();
		Item Itemsaved=itemRepository.findOne(itemId);
		Itemsaved.setAvailable(Itemsaved.getAvailable()+quantityBooked);
		itemRepository.save(Itemsaved);
		itemBookedRepository.delete(id);
		
	}

}

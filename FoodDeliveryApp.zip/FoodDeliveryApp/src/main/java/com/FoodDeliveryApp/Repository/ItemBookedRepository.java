package com.FoodDeliveryApp.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.FoodDeliveryApp.Model.ItemBooked;

@Repository("itemBookedRepository")
public interface ItemBookedRepository extends CrudRepository<ItemBooked,Integer> {

}

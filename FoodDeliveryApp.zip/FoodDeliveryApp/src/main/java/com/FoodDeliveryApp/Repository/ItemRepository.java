package com.FoodDeliveryApp.Repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.FoodDeliveryApp.Model.Item;

@Repository("itemRepository")
public interface ItemRepository extends CrudRepository<Item, Integer>{

	@Query("from Item i where i.itemName=:name")
	Item findbyName(@Param("name")String name);

}
